import 'dart:async';

import 'package:chatbot/chatbot.dart';
import 'package:flutter/material.dart';




class Splash extends StatefulWidget {
  const Splash({ Key? key }) : super(key: key);

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(Duration(seconds:5), (){
     Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>Chatbot() ));

    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(

    backgroundColor: Colors.black,
     body: Center(
       child: Column(
     
       mainAxisAlignment: MainAxisAlignment.center,
       children: [
        
        Container(
        height: 200,
        width: 200,
        child: Image.network('https://distok.top/stickers/754103543786504244/754109076933443614.gif',
        fit: BoxFit.cover,
        ),
        
        ),
        Text("SUSTbot",
        
        style: TextStyle(
         fontSize: 60.0,
         fontWeight: FontWeight.bold,
         color: Colors.green,

        ),
        
        ),
      SizedBox(
        height: 20,
      ),
   CircularProgressIndicator(

     valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
   ),


       ],
     
       ),
     ),




      
    );
  }
}